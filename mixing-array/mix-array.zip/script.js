let firstArray = [1, 2, 3, 4]
let secondArray = [2, 4, 6]
const offset = 1

const mixArrayWRTOffset = (arr1, arr2, offset) => {
  arr1.push(...arr2)
  let newArray = arr1
  for(let i = 0; i < newArray.length; i++){
   
  }
}

mixArrayWRTOffset(firstArray, secondArray, offset)